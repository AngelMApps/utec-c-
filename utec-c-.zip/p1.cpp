#include<iostream> 
using namespace std;  

int main(){           
	std::cout << "Hola Mundo!";   
    std::cout << "Angel Mora";
	return 0;                     
}

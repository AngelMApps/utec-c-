//
// Created by dev on 5/10/21.
//

#ifndef P1_P1_H
#define P1_P1_H

#include <iostream>
using namespace std;
void ingresarNotas(string &notas);
void cambiarNota(string &notas);
void eliminarNota(string &notas);
#endif //P1_P1_H

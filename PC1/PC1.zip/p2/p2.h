//
// Created by dev on 5/10/21.
//

#ifndef P2_P2_H
#define P2_P2_H
void binario(int n);
#endif //P2_P2_H

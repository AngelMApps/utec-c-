//
// Created by dev on 5/10/21.
//

#ifndef P3_P3_H
#define P3_P3_H
void ingresarDatos(float &r, float &p);
void calculoCostos(float r, float p,float &cExcavacion,float &cRecubrimiento, float &cTotal);
void showResultados(float cExcavacion,float cRecubrimiento,float cTotal);
#endif //P3_P3_H
